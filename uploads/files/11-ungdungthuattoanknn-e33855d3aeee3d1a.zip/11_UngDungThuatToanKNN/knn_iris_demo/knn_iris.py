import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report


def main() -> None:
    # 1) Load data
    iris = load_iris()
    X, y = iris.data, iris.target
    target_names = iris.target_names

    # 2) Train/test split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )

    # 3) Scale
    scaler = StandardScaler()
    X_train_sc = scaler.fit_transform(X_train)
    X_test_sc = scaler.transform(X_test)

    # 4) Pick best k
    ks = range(1, 31)
    accs = []
    for k in ks:
        model = KNeighborsClassifier(n_neighbors=k)
        model.fit(X_train_sc, y_train)
        pred = model.predict(X_test_sc)
        accs.append(accuracy_score(y_test, pred))

    best_k = ks[int(np.argmax(accs))]
    best_acc = float(max(accs))

    print("========================================")
    print("KNN + Iris")
    print("========================================")
    print(f"Best k: {best_k}")
    print(f"Best accuracy (test): {best_acc:.4f}")

    # 5) Train final model
    final_model = KNeighborsClassifier(n_neighbors=best_k)
    final_model.fit(X_train_sc, y_train)
    y_pred = final_model.predict(X_test_sc)

    print("\n--- Confusion Matrix ---")
    print(confusion_matrix(y_test, y_pred))

    print("\n--- Classification Report ---")
    print(classification_report(y_test, y_pred, target_names=target_names))

    # 6) Demo input
    print("\n--- DEMO NHẬP LIỆU ---")
    print("Nhập 4 số theo thứ tự:")
    print("sepal_length sepal_width petal_length petal_width")
    print("Ví dụ Setosa:      5.1 3.5 1.4 0.2")
    print("Ví dụ Versicolor:  6.0 2.9 4.5 1.5")
    print("Ví dụ Virginica:   6.5 3.0 5.5 2.0")
    print("Gõ 'q' để thoát.\n")

    while True:
        s = input("Nhập 4 giá trị: ").strip()
        if s.lower() == "q":
            print("Thoát demo.")
            break

        parts = s.split()
        if len(parts) != 4:
            print("❌ Bạn phải nhập đúng 4 số. Ví dụ: 5.1 3.5 1.4 0.2\n")
            continue

        try:
            values = np.array([float(x) for x in parts], dtype=float).reshape(1, -1)
        except ValueError:
            print("❌ Giá trị không hợp lệ. Hãy nhập số (float).\n")
            continue

        values_sc = scaler.transform(values)  # chuẩn hoá giống lúc train
        pred_class = int(final_model.predict(values_sc)[0])
        print("✅ Dự đoán:", target_names[pred_class], "\n")


if __name__ == "__main__":
    main()
