Cài đặt
1️⃣ Tạo virtual environment
->Windows
python -m venv venv
venv\Scripts\activate

->Mac / Linux
python3 -m venv venv
source venv/bin/activate

2️⃣ Cài thư viện
pip install -r requirements.txt

▶️ Chạy chương trình
python knn_iris.py